package com.shop.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.shop.biz.ShopBizService;
import com.shop.entity.Item;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequestMapping("/api/shop")
@RequiredArgsConstructor
public class BizController {

    private final ShopBizService shopBizService;

    @PostMapping("/cart-items/{userId}/{itemId}")
    public ResponseEntity<String> addItemToUserCart(@PathVariable Long userId, @PathVariable Long itemId) {
        try {
            shopBizService.addItemToUserCart(userId, itemId);
            return ResponseEntity.status(HttpStatus.OK).body("Item added to cart successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to add item to cart");
        }
    }

    @DeleteMapping("/cart-items/{userId}/{itemId}")
    public ResponseEntity<String> removeItemFromUserCart(@PathVariable Long userId, @PathVariable Long itemId) {
        try {
            shopBizService.removeItemFromUserCart(userId, itemId);
            return ResponseEntity.status(HttpStatus.OK).body("Item removed from cart successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to remove item from cart");
        }
    }

    @GetMapping("/cart-items/{userId}")
    public ResponseEntity<List<Item>> getUserCartItems(@PathVariable Long userId) {
        try {
            List<Item> items = shopBizService.getUserCartItems(userId);
            return ResponseEntity.ok(items);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
}

